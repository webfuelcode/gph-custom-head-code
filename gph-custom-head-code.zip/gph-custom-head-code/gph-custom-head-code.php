<?php
/**
 * Plugin Name: GPH Custom Head Code
 * Plugin URI: https://gopickhost.com
 * Description: Your light weighted head code injector to put code within <head> & </head>. Add custom CSS, HTML, or text code to your website's head section easily.
 * Version: 1.0.0
 * Author: Johnthan
 * Author URI: https://gopickhost.com
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class CustomHeadCode {
    
    private $option_name = 'custom_head_code_content';
    
    public function __construct() {
        add_action('init', array($this, 'init'));
    }
    
    public function init() {
        // Add admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // Add settings
        add_action('admin_init', array($this, 'admin_init'));
        
        // Add code to head
        add_action('wp_head', array($this, 'add_head_code'));
        
        // Add admin styles
        add_action('admin_enqueue_scripts', array($this, 'admin_styles'));
    }
    
    public function add_admin_menu() {
        add_options_page(
            'GPH Custom Head Code',
            'Head Code',
            'manage_options',
            'custom-head-code',
            array($this, 'admin_page')
        );
    }
    
    public function admin_init() {
        register_setting(
            'custom_head_code_group',
            $this->option_name,
            array($this, 'sanitize_content')
        );
        
        add_settings_section(
            'custom_head_code_section',
            'Head Code Settings',
            array($this, 'section_callback'),
            'custom-head-code'
        );
        
        add_settings_field(
            'head_code_field',
            'GPH Custom Head Code',
            array($this, 'field_callback'),
            'custom-head-code',
            'custom_head_code_section'
        );
    }
    
    public function section_callback() {
        echo '<p>Enter your custom CSS, HTML, or text code that you want to add to the head section of your website.</p>';
    }
    
    public function field_callback() {
        $content = get_option($this->option_name, '');
        ?>
        <div class="head-code-container">
            <textarea 
                name="<?php echo $this->option_name; ?>" 
                id="head-code-textarea"
                rows="20" 
                cols="80"
                placeholder="Enter your Custom Head Code here...

Examples:
<!-- Custom CSS -->
<style>
body { background-color: #f0f0f0; }
</style>

<!-- Meta tags -->
<meta name='keywords' content='your, keywords, here'>

<!-- Custom JavaScript -->
<script>
console.log('GPH Custom Head Code loaded');
</script>

<!-- External stylesheets -->
<link rel='stylesheet' href='https://example.com/style.css'>

<!-- Google Analytics, Facebook Pixel, etc. -->
"><?php echo esc_textarea($content); ?></textarea>
            
            <div class="head-code-info">
                <h4>What you can add:</h4>
                <ul>
                    <li><strong>CSS Styles:</strong> Wrap in &lt;style&gt; tags</li>
                    <li><strong>JavaScript:</strong> Wrap in &lt;script&gt; tags</li>
                    <li><strong>Meta Tags:</strong> For SEO, social media, etc.</li>
                    <li><strong>External Links:</strong> Stylesheets, fonts, etc.</li>
                    <li><strong>Analytics Code:</strong> Google Analytics, Facebook Pixel, etc.</li>
                    <li><strong>Custom HTML:</strong> Any valid HTML code</li>
                </ul>
                
                <div class="notice notice-warning inline">
                    <p><strong>Important:</strong> Only add code from trusted sources. Malicious code can harm your website.</p>
                </div>
            </div>
        </div>
        <?php
    }
    
    public function sanitize_content($input) {
        // Allow all HTML tags and attributes for head content
        // Users should be administrators who know what they're doing
        return $input;
    }
    
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>GPH Custom Head Code</h1>
            
            <div class="head-code-admin-wrap">
                <form method="post" action="options.php">
                    <?php
                    settings_fields('custom_head_code_group');
                    do_settings_sections('custom-head-code');
                    ?>
                    
                    <div class="submit-section">
                        <?php submit_button('Save Head Code', 'primary', 'submit', false); ?>
                        <button type="button" id="clear-code" class="button button-secondary">Clear All</button>
                        <button type="button" id="preview-code" class="button button-secondary">Preview Code</button>
                    </div>
                </form>
                
                <div id="code-preview" class="code-preview" style="display: none;">
                    <h3>Code Preview:</h3>
                    <pre id="preview-content"></pre>
                </div>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Clear all code
            $('#clear-code').click(function() {
                if (confirm('Are you sure you want to clear all head code?')) {
                    $('#head-code-textarea').val('');
                }
            });
            
            // Preview code
            $('#preview-code').click(function() {
                var code = $('#head-code-textarea').val();
                if (code.trim() === '') {
                    alert('No code to preview');
                    return;
                }
                
                $('#preview-content').text(code);
                $('#code-preview').toggle();
            });
            
            // Auto-resize textarea
            $('#head-code-textarea').on('input', function() {
                this.style.height = 'auto';
                this.style.height = (this.scrollHeight) + 'px';
            });
        });
        </script>
        <?php
    }
    
    public function add_head_code() {
        $content = get_option($this->option_name, '');
        
        if (!empty(trim($content))) {
            echo "\n<!-- GPH Custom Head Code Plugin -->\n";
            echo $content;
            echo "\n<!-- End GPH Custom Head Code -->\n";
        }
    }
    
    public function admin_styles($hook) {
        if ('settings_page_custom-head-code' !== $hook) {
            return;
        }
        
        ?>
        <style>
        .head-code-container {
            display: flex;
            gap: 20px;
            margin-top: 10px;
        }
        
        #head-code-textarea {
            font-family: 'Courier New', monospace;
            font-size: 13px;
            line-height: 1.4;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 10px;
            background: #fafafa;
            resize: vertical;
            min-height: 400px;
            flex: 1;
        }
        
        .head-code-info {
            width: 300px;
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 15px;
        }
        
        .head-code-info h4 {
            margin-top: 0;
            color: #333;
        }
        
        .head-code-info ul {
            margin: 10px 0;
            padding-left: 20px;
        }
        
        .head-code-info li {
            margin-bottom: 5px;
        }
        
        .submit-section {
            margin-top: 20px;
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .code-preview {
            margin-top: 20px;
            background: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 15px;
        }
        
        .code-preview pre {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 10px;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            line-height: 1.4;
            overflow-x: auto;
            max-height: 300px;
            overflow-y: auto;
        }
        
        .head-code-admin-wrap {
            max-width: 1200px;
        }
        
        .notice.inline {
            margin: 15px 0;
            padding: 8px 12px;
        }
        </style>
        <?php
    }
}

// Initialize the plugin
new CustomHeadCode();

// Activation hook
register_activation_hook(__FILE__, 'custom_head_code_activate');
function custom_head_code_activate() {
    // Create default option
    add_option('custom_head_code_content', '');
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'custom_head_code_deactivate');
function custom_head_code_deactivate() {
    // Option is kept for when plugin is reactivated
}

// Uninstall hook
register_uninstall_hook(__FILE__, 'custom_head_code_uninstall');
function custom_head_code_uninstall() {
    // Remove the option when plugin is deleted
    delete_option('custom_head_code_content');
}
?>